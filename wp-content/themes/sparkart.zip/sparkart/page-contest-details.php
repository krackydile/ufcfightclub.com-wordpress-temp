<?php
get_header();
if (have_posts()):
    while (have_posts()):
        the_post();
        ?>

        <section class="page-section">
            <div class="container">
                <h3 class="block-heading text-center mt-4 mb-5"><span><?php the_title(); ?> </span></h3>
<?php
$contest_details = Universe\fetch_resource('contests/?event_id='.$event_details->event->id, '3af65919-3f76-46c8-b905-0f952ffcbd47');
?>


            </div>
        </section>

    <?php
    endwhile;
endif;
get_footer()
?>
