<?php
/**
 * Template Name: Universe Logout
 */

include( WP_PLUGIN_DIR . '/universe-js/login/logout.php');
?>
