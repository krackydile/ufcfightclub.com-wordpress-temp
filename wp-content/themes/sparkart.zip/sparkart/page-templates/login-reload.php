<?php
/**
 * Template Name: Universe Login Reload
 */

include( WP_PLUGIN_DIR . '/universe-js/login/closePromptPopup.php');

?>
