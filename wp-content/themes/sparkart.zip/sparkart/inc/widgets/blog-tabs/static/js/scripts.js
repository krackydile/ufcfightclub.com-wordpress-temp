jQuery(document).ready(function () {
	jQuery(".wrap-tabs").tabs();
});