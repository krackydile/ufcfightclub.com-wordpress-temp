<section class="upcomming-events py-5 ">
	<div class="container">
		<h3 class="block-heading heading-light text-center mt-4 mb-5"><span><?php echo $atts['heading'] ?></span></h3>
		<?php 
			homepage_event_cards();
			homepage_more_events();
		?>
		

	</div>
	
</section>