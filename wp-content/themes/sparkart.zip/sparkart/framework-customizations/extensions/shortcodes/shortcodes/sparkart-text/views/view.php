<section class="sparkart-text">
	<div class="container">

		<div class="row">
			<div class="col">
				<?php echo $atts['content']; ?>
			</div>
		</div>
	</div>
</section>