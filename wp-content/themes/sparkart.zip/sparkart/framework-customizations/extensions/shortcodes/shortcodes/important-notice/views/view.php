<section class="sparkart-important-nontices">
	<div class="container">

		<div class="row">
			<div class="col">
				<h2><?php echo $atts['notice_heading']; ?></h2>
				<h3><?php echo $atts['notice_subtext']; ?></h3>
				<?php echo $atts['notice_content']; ?>
			</div>
		</div>
	</div>
</section>