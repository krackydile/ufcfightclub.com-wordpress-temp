<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'heading'                      => array(
		'label' => __( 'Heading', 'unyson' ),
		'type'  => 'text',
		'value' => 'News',
	),
	

);