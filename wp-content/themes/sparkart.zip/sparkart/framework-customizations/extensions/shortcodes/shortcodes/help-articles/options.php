<?php 
if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'help_introducation'                      => array(
		'label' => __( 'Content', 'unyson' ),
		'type'  => 'wp-editor',
	),
	
);