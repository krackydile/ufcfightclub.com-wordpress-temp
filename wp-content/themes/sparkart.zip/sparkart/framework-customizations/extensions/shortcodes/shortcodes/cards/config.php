<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Cards', 'unyson' ),
		'description' => __( 'Cards layout', 'unyson' ),
		'tab'         => __( 'Sparkart Elements', 'fw' ),
	)
);
// $cfg = [];