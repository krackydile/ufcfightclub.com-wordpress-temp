<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Image Block', 'unyson' ),
		'description' => __( 'Standard block with image on one side and text on the other', 'unyson' ),
		'tab'         => __( 'Sparkart Elements', 'fw' ),
	)
);
// $cfg = [];