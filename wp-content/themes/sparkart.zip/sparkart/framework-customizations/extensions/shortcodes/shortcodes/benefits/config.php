<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Benefits', 'unyson' ),
		'description' => __( 'Benefits layout ', 'unyson' ),
		'tab'         => __( 'Sparkart Elements', 'fw' ),
	)
);