<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'News(Tabbed)', 'unyson' ),
		'description' => __( 'Tabbed news layout usually used in homepage', 'unyson' ),
		'tab'         => __( 'Sparkart Elements', 'fw' ),
	)
);