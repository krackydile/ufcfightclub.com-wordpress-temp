<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Events Tabs', 'unyson' ),
		'description' => __( 'Shows the events in a tabbed format.', 'unyson' ),
		'tab'         => __( 'Sparkart Elements', 'fw' ),
	)
);