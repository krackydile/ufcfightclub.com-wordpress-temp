<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Demo 3', 'unyson' ),
		'description' => __( 'Demo of a shortcode with custom class', 'unyson'),
		'tab'         => __( 'Content Elements', 'fw' )
	)
);