<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Sparkart Text block', 'unyson' ),
		'description' => __( 'Sparkart ext blocks', 'unyson' ),
		'tab'         => __( 'Sparkart Elements', 'fw' ),
	)
);
// $cfg = [];