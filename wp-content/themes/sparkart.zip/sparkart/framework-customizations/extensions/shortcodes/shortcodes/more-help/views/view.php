<?php 
	fw_print_more_help();
?>