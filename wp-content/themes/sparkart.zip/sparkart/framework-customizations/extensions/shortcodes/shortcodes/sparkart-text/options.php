<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	
	'content'                      => array(
		'label' => __( 'Content', 'unyson' ),
		'type'  => 'wp-editor',
	),
	
);