<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Demo Disabled', 'unyson' ),
		'description' => __( 'Demo of a shortcode that should be disabled', 'unyson' ),
		'tab'         => __( 'Content Elements', 'fw' ),
	)
);