<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Sparkart More Help', 'unyson' ),
		'description' => __( 'Sparkart important notice block', 'unyson' ),
		'tab'         => __( 'Sparkart Elements', 'fw' ),
	)
);
// $cfg = [];