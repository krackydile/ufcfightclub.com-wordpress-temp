<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Image Carousel', 'unyson' ),
		'description' => __( 'Full width image Carousel', 'unyson' ),
		'tab'         => __( 'Sparkart Elements', 'fw' ),
	)
);