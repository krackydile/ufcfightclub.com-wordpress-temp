<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Events', 'unyson' ),
		'description' => __( 'Events layout usually used in homepage', 'unyson' ),
		'tab'         => __( 'Sparkart Elements', 'fw' ),
	)
);