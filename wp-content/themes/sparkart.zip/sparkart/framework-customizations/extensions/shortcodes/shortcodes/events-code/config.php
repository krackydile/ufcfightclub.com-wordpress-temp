<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Events Code', 'unyson' ),
		'description' => __( 'Section which shows the events Code', 'unyson' ),
		'tab'         => __( 'Sparkart Elements', 'fw' ),
	)
);