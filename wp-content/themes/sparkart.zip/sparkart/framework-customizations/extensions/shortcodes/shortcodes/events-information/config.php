<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Event Information', 'unyson' ),
		'description' => __( 'Section which shows the event information', 'unyson' ),
		'tab'         => __( 'Sparkart Elements', 'fw' ),
	)
);