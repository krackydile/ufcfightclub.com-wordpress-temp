<?php 
// if ( ! defined( 'FW' ) ) {
// 	die( 'Forbidden' );
// }

// $options = array(
// 	'more_notice_heading'                      => array(
// 		'label' => __( 'Heading', 'unyson' ),
// 		'type'  => 'text',
// 	),
	
// 	'more_notice_content'                      => array(
// 		'label' => __( 'Content', 'unyson' ),
// 		'type'  => 'wp-editor',
// 	),
	
// );