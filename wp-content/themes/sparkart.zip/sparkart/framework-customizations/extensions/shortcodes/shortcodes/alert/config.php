<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Help Alert', 'unyson' ),
		'description' => __( 'Alert box shown in help page', 'unyson' ),
		'tab'         => __( 'Sparkart Elements', 'fw' ),
	)
);