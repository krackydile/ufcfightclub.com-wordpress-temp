<?php if (!defined('FW')) die('Forbidden');

require dirname(__FILE__) .'/../shortcodes/section/includes/template-component/init.php';
require dirname(__FILE__) .'/../shortcodes/column/includes/template-component/init.php';
