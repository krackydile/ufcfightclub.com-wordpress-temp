<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Testimonials', 'fw' ),
	'description' => __( 'Add some Testimonials', 'fw' ),
	'tab'         => __( 'Content Elements', 'fw' ),
);